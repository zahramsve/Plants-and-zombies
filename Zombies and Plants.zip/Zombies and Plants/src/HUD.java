import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;

public class HUD {
//////////////////////////////////////////For plants and zombies health/////////////////////////////////////////////////
    private boolean check=true , check2=true;
    public static int HEALTH =100 , SunNum = 50;

    public void tick(){
        if(check){
            Timer timer = new Timer();

            TimerTask task = new TimerTask() {
                public void run() {
                    HEALTH--;
                }
            };
            timer.scheduleAtFixedRate(task,0,2000);
            check=false;
        }
        if(check2){
            Timer timer2 = new Timer();

            TimerTask task2 = new TimerTask() {
                public void run() {
                    SunNum+=25;
                }
            };
            timer2.scheduleAtFixedRate(task2,5000,5000);
            check2 = false;
        }
        HEALTH = Game.clamp(HEALTH,0);
    }

    public void render(Graphics g){
        if(Main.SunNSp>0) SunNum = Main.SunNSp;
        g.setColor(Color.gray);
        g.fillRect(120,10,200,20);
        g.setColor(Color.green);

        g.fillRect(120,10,HEALTH*2,20);
        g.setColor(Color.white);
        g.drawRect(120,10,200,20);

        g.setColor(Color.BLACK);
        g.setFont(new Font("kranky", Font.BOLD, 20));
        g.drawString(String.valueOf(SunNum), 50,105);
    }
}
