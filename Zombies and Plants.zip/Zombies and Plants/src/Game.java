import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferStrategy;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class Game extends Canvas implements Runnable{

        /*
        A Canvas component represents a blank rectangular area of the screen onto which the application can draw or
        from which the application can trap input events from the user.
         */

    private static final long serialVersionUID = 552953289469613480L;
    public static final int Width =1100 , Height = Width*9 /16;//height=618

    Thread thread;
    static boolean running= false; //for start game.
    private Handler handler;
    int zombieNumber = 5 , zombieComing =0;
    private Random r;
    private int[] row= {55,140,235,320,410};
    private HUD hud;
    private boolean checkz=true ,winCheck=true;
    static Timer zombieCTimer;
    public Game(){
//////////////////////////////////////// Go to gamewindow class that our frame is in that //////////////////////////////
        new GameWindow(Width,Height , "PLANTS VS ZOMBIES" , this);
        handler = new Handler();
        this.addMouseListener(new MouseInput(handler));
        zombieCome();
        hud = new HUD();
        r= new Random();
    }

    public synchronized void start(){
////////////////////////////////////////////For start Thread and game///////////////////////////////////////////////////
        thread = new Thread(this);
        thread.start();
        running=true;
    }

    public synchronized void stop(){
//////////////////////////////////////////////////For stop game/////////////////////////////////////////////////////////
        try {
            thread.join(); //join stop the thread
            running = false;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
///////////////////////////////////////game loop which is heart beat of the game :) ////////////////////////////////////
       //this.requestFocus();
        long lastTime = System.nanoTime();
        double amountOfTicks = 60.0;
        double ns = 1000000000 / amountOfTicks;
        double delta =0;
        long  timer = System.currentTimeMillis();
        int frames=0;

        while (running){
            long now = System.nanoTime();
            delta += (now-lastTime)/ ns ;
            lastTime = now ;
            while (delta>=1){
                tick();
                delta--;
            }

            if(running)
                render();
            frames++;

            if(System.currentTimeMillis()- timer >1000){
                timer +=1000;
                frames =0;
            }
        }
        stop();
    }

    private void tick(){
        handler.tick();
        hud.tick();
    }

    private void render(){
        BufferStrategy bs = this.getBufferStrategy();
        if(bs == null ){
            this.createBufferStrategy(3);
            return;
        }
        Graphics g = bs.getDrawGraphics();
        ImageIcon back = new ImageIcon("background.jpg");

        g.setColor(Color.BLACK);
        g.fillRect(0,0,Width,Height);

        g.drawImage(back.getImage() ,0,0,Width,Height-47,null);
        handler.render(g);
        hud.render(g);
        g.dispose();
        bs.show();
    }

    public static int clamp(int var , int min ){
         if(var<=min)
            return var= min;
        else
            return var;

    }

    public void zombieCome(){
        if(Main.ZombieNSp >0){
            zombieNumber = Main.ZombieNSp;
        }
        if(checkz && zombieComing<=zombieNumber){
            System.out.println(zombieNumber);
            zombieCTimer = new Timer();
            TimerTask task = new TimerTask() {
                @Override
                public void run() {
                        int zombiePlace = r.nextInt(row.length);
                        int zombieType = r.nextInt(2);
                        if(zombieType == 0){
                            handler.addObject(new NormalZombie(1100,row[zombiePlace], ID.NormalZombie ,handler));
                            zombieComing++;
                        }
                        else if(zombieType == 1){
                            handler.addObject(new ConeHeadZombie(1100,row[zombiePlace]-13, ID.ConeHeadZombie , handler));
                            zombieComing++;
                        }

                        if(zombieComing==zombieNumber){
                            for(int i=0 ; i<handler.object.size() ;i++) {
                                Entity tempObject = handler.object.get(i);
                                Zombies temp = (Zombies) handler.object.get(i);
                                if (tempObject.getId() == ID.NormalZombie || tempObject.getId() == ID.ConeHeadZombie){
                                    if(tempObject.getX() != 240 && temp.getHealth()==0){
                                        if(winCheck){
                                            winForm s = new winForm();
                                            s.winframe.setSize(Width-53, Height);
                                            s.winframe.setVisible(true);
                                            s.winframe.setLocationRelativeTo(null);
                                            s.winframe.setContentPane(s.panel1);
                                            s.winframe.addMouseListener(new winForm());
                                            MouseInput.overClick=true;
                                            winCheck=false;
                                        }

                                    }
                                }
                            }
                        }
//                        System.out.println("zc:" +zombieComing);
//                    System.out.println("zn:"+zombieNumber);
                }
            };
            zombieCTimer.scheduleAtFixedRate(task,5000,5000);
            checkz=false;
        }
    }
}