import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MouseInput extends MouseAdapter {

    int[] row= {55,150,245,340,420,515};
    int[] column = {270,355,440,520,615,710,790,870,960,1060};
    int[] columnPlanting = {280,365,450,530,625,720,800,880,970,1070};
    long sun =0 , peashooter=0 ,potato=0 ,repeater=0;
    boolean sunS=false , peashooterS= false, potatoS = false , repeaterS = false;
    private Handler handler;
    static boolean overClick = false;

    public MouseInput(Handler handler){
        this.handler=handler;
    }

    public void mouseClicked(MouseEvent e) {

        double x = e.getX() , y = e.getY();
        System.out.println("x: "+x + " , y: " + y);

        if(x>=12 && x<= 110){
//////////////////////////////////////////for figure out which kind of plants was selected//////////////////////////////
            if(y>=122 && y<= 205){
////////////////////if when click on one and then click on another in that time last one is wrong///////////////////////
                peashooterS= false ; potatoS = false ; repeaterS = false;
                System.out.println("sun flower Selected");
                sunS=true;
            }

            else if(y>= 215 && y<=300){
                sunS=false ;potatoS = false ; repeaterS = false;
                System.out.println("peashooter selected");
                peashooterS=true;
            }

            else if(y>= 310 && y<=390){
                sunS=false ; peashooterS= false ; repeaterS = false;
                System.out.println("potato selected");
                potatoS=true;
            }

            else if(y>= 400 && y<=480){
                sunS=false ; peashooterS= false ; potatoS = false ;
                System.out.println("repeater selected");
                repeaterS=true;
            }
        }

        else if(x>=270 && x<=1060 && y>=55 && y<=515){
///////////////////////////////if one of them is true and we choose where is it planted its planted:\ //////////////////
            if(sunS){
               long suncooldown = System.currentTimeMillis() - sun;
                if(suncooldown> 3000 && HUD.SunNum >= 50){
                    handler.addObject(new SunFlower(columnPlanting[getColumn(x)-1],row[getRow(y)-1] , ID.SunFlower ,handler));
                    sun = System.currentTimeMillis();
                    sunS = false;
                }
            }

            else if(peashooterS){
                long peacooldown  = System.currentTimeMillis() - peashooter;
                if (peacooldown>3000 && HUD.SunNum >=100){
                    handler.addObject(new PeaShooter(columnPlanting[getColumn(x)-1],row[getRow(y)-1] ,ID.PeaShooter,handler));
                    peashooter = System.currentTimeMillis();
                    peashooterS=false;
                }

            }

            else if(repeaterS){
                long repeacooldown = System.currentTimeMillis() - repeater;
                if(repeacooldown>3000 && HUD.SunNum >=200){
                    handler.addObject(new RePeater(columnPlanting[getColumn(x)-1],row[getRow(y)-1] ,ID.ReaPeater ,handler));
                    repeater = System.currentTimeMillis();
                    repeaterS = false;
                }

            }

            else if(potatoS){
                long potatocooldown = System.currentTimeMillis() - potato;
                if(potatocooldown>3000 && HUD.SunNum >=25){
                    handler.addObject(new Potato(columnPlanting[getColumn(x)-1],row[getRow(y)-1] ,ID.Potato ,handler));
                    potato =System.currentTimeMillis();
                    potatoS=false;
                }

            }
        }

        if(overClick){
            if(x>=370 && x<=720){
                if(y<=490 && y>= 425){
                    Game.zombieCTimer.cancel();
                    GameWindow.frame.setVisible(false);
                    Main.firstFrame.setVisible(true);
                    overClick =false;
                }
            }
        }
    }

    int getRow(double y){
////////////////////////////////////to now our 'y' that we choose is in what home of array//////////////////////////////
        for(int i=1 ; i<row.length ; i++){
            if(y> row[i-1] && y<=row[i]){
                return i;
            }
        }
        return -1;
    }

    int getColumn(double x){
////////////////////////////////////to now our 'x' that we choose is in what home of array//////////////////////////////

        for(int i=1 ; i<column.length ; i++){
            if(x> column[i-1] && x<=column[i]){
                return i;
            }
        }
        return -1;
    }
}
