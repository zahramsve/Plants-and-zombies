import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;

public class Pea extends Plants{
    Handler handler;

    public Pea(int x, int y, ID id , Handler handler) {
        super(x, y, id);
        Health=10;
        velX=2d;
        velY=0d;
        this.handler = handler;
    }
    @Override
    public void tick() {
        x += velX;
        y += velY;
        collision();
    }
    private void collision(){
        for(int i=0 ; i<handler.object.size() ;i++) {
            Entity tempObject = handler.object.get(i);
            if (tempObject.getId() == ID.NormalZombie || tempObject.getId() == ID.ConeHeadZombie) {
                if(getBounds().intersects(tempObject.getBounds())){

                    java.util.Timer remove = new Timer();

                    TimerTask rTask = new TimerTask() {
                        @Override
                        public void run() {
                            Health=0;
                        }
                    };

                    remove.schedule(rTask, 10);
                }
            }
        }
    }
    @Override
    public void render(Graphics g) {
        ImageIcon pea = new ImageIcon("Pea.png");
//        Graphics2D g2d = (Graphics2D) g;
//        g.setColor(Color.black);
//        g2d.draw(getBounds());
        g.drawImage(pea.getImage() , x+50,y+15,null);

        if(Health==0){
             handler.removeObject(this);
        }
    }

    @Override
    public Rectangle getBounds() {
        return new Rectangle( x+50 ,y+15 , 20, 20);
    }

}
