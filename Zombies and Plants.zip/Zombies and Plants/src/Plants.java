import java.awt.*;

public abstract class Plants extends Entity{
    protected int  Health,price;
    public Plants(int x, int y, ID id) {
        super(x, y, id);
    }

    @Override
    public void tick() {}

    @Override
    public void render(Graphics g) {}

}
