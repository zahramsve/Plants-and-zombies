import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class winForm extends MouseAdapter {
    static JFrame winframe;
    public JPanel panel1;
    private JLabel Label1;

    public winForm(){
        winframe = new JFrame();
        ImageIcon icon = new ImageIcon("iconImage.png");
        winframe.setPreferredSize(new Dimension(Game.Width-53, Game.Height));
        winframe.setMaximumSize(new Dimension(Game.Width-53, Game.Height));
        winframe.setMinimumSize(new Dimension(Game.Width-53, Game.Height));
        winframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        winframe.setResizable(false);
        winframe.setIconImage(icon.getImage());
        Game.zombieCTimer.cancel();
        GameWindow.frame.setVisible(false);
    }


    @Override
    public void mouseClicked(MouseEvent e) {
        double x=e.getX(),y=e.getY();
        System.out.println("x:"+x + " y:"+y);
        if(x>=360 && x<=685){
            if(y<=569 && y>= 505){
                winframe.setVisible(false);
                Game.zombieCTimer.cancel();
                Main.firstFrame.setVisible(true);
            }
        }
    }
}
