import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;

public class Potato extends Plants{
    Handler handler;
    public Potato(int x, int y, ID id ,Handler handler) {
        super(x, y, id);
        this.handler = handler;
        Health=1;
        velX = 0d;
        velY = 0d;
    }

    public void tick() {
        x += velX;
        y += velY;
        collision();
    }

    private void collision(){
        for(int i=0 ; i<handler.object.size() ;i++) {
            Entity tempObject = handler.object.get(i);
            if(tempObject.getId() == ID.NormalZombie ||tempObject.getId() == ID.ConeHeadZombie)
            {
                if (getBounds().intersects(tempObject.getBounds())) {
                    Health=0;
                }
            }
        }
    }

    public void render(Graphics g) {
        ImageIcon potato = new ImageIcon("walnut_full_life.gif");

//        Graphics2D g2d = (Graphics2D) g;
//        g.setColor(Color.black);
//        g2d.draw(getBounds());
        g.drawImage(potato.getImage() , x, y,null);

        g.setColor(Color.gray);
        g.fillRect(x+5,y+75,60,5);

        g.setColor(Color.green);
        g.fillRect(x+5,y+75,Health*60,5);

        g.setColor(Color.white);
        g.drawRect(x+5,y+75,60,5);

        if(Health==0){
            handler.removeObject(this);
        }


    }


    @Override
    public Rectangle getBounds() {
        return new Rectangle(x , y , 75, 75);
    }

}
