import javax.swing.*;
import java.awt.*;

public class Zombies extends Entity{

    public int getHealth() {
        return Health;
    }

    int Health;

    public Zombies(int x, int y, ID id) {
        super(x, y, id);
    }

    @Override
    public void tick() {}

    @Override
    public void render(Graphics g) {}

    @Override
    public Rectangle getBounds() {
        return null;
    }

}
