import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;

public class SunFlower extends Plants{
    Handler handler;
    private boolean check = true , sunTimer=true;
    private Timer healthtimer , suntimer;
    public SunFlower(int x, int y, ID id ,Handler handler) {
        super(x, y, id);
        this.handler = handler;
        Health=3;
        velX = 0d;
        velY = 0d;
    }
//    public SunFlower(HUD health){
//
//    }

    public void tick() {
        x += velX;
        y += velY;

        collision();
    }

    private void collision(){

        for(int i=0 ; i<handler.object.size() ;i++){
            Entity tempObject = handler.object.get(i);

            if(tempObject.getId() == ID.NormalZombie ||tempObject.getId() == ID.ConeHeadZombie)
            {
                if(getBounds().intersects(tempObject.getBounds())){
                    if(check){
                         healthtimer = new Timer();

                        TimerTask task = new TimerTask() {
                            @Override
                            public void run() {
                                Health--;
                                System.out.println(Health);
                            }
                        };
                        healthtimer.scheduleAtFixedRate(task,0,1000);
                        check = false;
                    }

                }
                }
            }
        }

    public void render(Graphics g) {
        ImageIcon sunFlower = new ImageIcon("sun_flower.gif");
//        Graphics2D g2d = (Graphics2D) g;
//        g.setColor(Color.black);
//        g2d.draw(getBounds());
        g.drawImage(sunFlower.getImage() , x, y,null);
        suntimer = new Timer();
        if(sunTimer){
            TimerTask task = new TimerTask() {
                @Override
                public void run() {
                    HUD.SunNum += 25;
                }
            };
            suntimer.scheduleAtFixedRate(task,0,5000);
            sunTimer =false;
        }


        if(Health==0) {
            healthtimer.cancel();
            handler.removeObject(this);
        }

        g.setColor(Color.gray);
        g.fillRect(x+5,y+75,60,5);

        g.setColor(Color.green);
        g.fillRect(x+5,y+75,Health*20,5);

        g.setColor(Color.white);
        g.drawRect(x+5,y+75,60,5);
    }

    @Override
    public Rectangle getBounds() {
        return new Rectangle(x,y,65,75);
    }
}
