import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;

public class RePeater extends Plants{
    boolean checkF=true , check=true;
    Handler handler;
    private Timer healthtimer,peatimer;
    public RePeater(int x, int y, ID id , Handler handler) {
        super(x, y, id);
        this.handler = handler;
        Health=3;
        velX = 0d;
        velY = 0d;
    }

    public void tick() {
        x += velX;
        y += velY;
        collision();
    }
    private void collision(){
        for(int i=0 ; i<handler.object.size() ;i++){
            Entity tempObject = handler.object.get(i);

            if(tempObject.getId() == ID.NormalZombie ||tempObject.getId() == ID.ConeHeadZombie)
            {
                if(getBounds().intersects(tempObject.getBounds())){
                    if(check){
                        healthtimer = new Timer();

                        TimerTask task = new TimerTask() {
                            @Override
                            public void run() {
                                Health--;
                            }
                        };

                        healthtimer.scheduleAtFixedRate(task,0,1000);
                        check = false;
                    }

                }
            }
        }
    }
    public void render(Graphics g) {
        ImageIcon rePeater = new ImageIcon("repeater.gif");
//        Graphics2D g2d = (Graphics2D) g;
//        g.setColor(Color.black);
//        g2d.draw(getBounds());
        g.drawImage(rePeater.getImage() , x, y,null);

        if(checkF){
            peatimer = new Timer();

            TimerTask task = new TimerTask() {
                @Override
                public void run() {

                            Pea pea1 = new Pea(x,y,ID.pea , handler);
                            handler.addObject(pea1);
                            Pea pea2 = new Pea(x+50,y,ID.pea , handler);
                            handler.addObject(pea2);


                }
            };

            peatimer.scheduleAtFixedRate(task,0,1500);
            checkF = false;
        }

        if(Health==0){
            healthtimer.cancel();
            peatimer.cancel();
            handler.removeObject(this);
        }

        g.setColor(Color.gray);
        g.fillRect(x+5,y+75,60,5);

        g.setColor(Color.green);
        g.fillRect(x+5,y+75,Health*20,5);

        g.setColor(Color.white);
        g.drawRect(x+5,y+75,60,5);

    }

    @Override
    public Rectangle getBounds() {
        return new Rectangle(x , y , 75, 75);
    }

}
