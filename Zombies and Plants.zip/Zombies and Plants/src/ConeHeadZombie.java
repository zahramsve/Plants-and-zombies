import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;

public class ConeHeadZombie extends Zombies {

    Handler handler;
    private Timer startAgain;
    public ConeHeadZombie(int x, int y, ID id ,Handler handler) {
        super(x, y, id);
        this.handler = handler;
        Health=200;
        velX = -0.000000000001d;
        velY = 0d;
    }
    @Override
    public void tick() {
        x += velX;
        y += velY;
        x= Game.clamp(x,240);
        collision();
    }

    private void collision(){
        for(int i=0 ; i<handler.object.size() ;i++){
            Entity tempObject = handler.object.get(i);
            if(tempObject.getId() == ID.pea) {
                if (getBounds().intersects(tempObject.getBounds())) {
                    Health -= 20;
                    System.out.println(Health);
                }
            }
            if(tempObject.getId() == ID.SunFlower ||tempObject.getId() == ID.PeaShooter||tempObject.getId() == ID.ReaPeater)
            {
                if(getBounds().intersects(tempObject.getBounds())){
                    velX=0d;
                    startAgain = new Timer();
                    TimerTask startTask = new TimerTask() {
                        @Override
                        public void run() {
                            velX = -0.000000000001d;
                        }
                    };
                    startAgain.schedule(startTask, 3000);
                }
            }
            if(tempObject.getId() == ID.Potato){
                if(getBounds().intersects(tempObject.getBounds())){
                    Health-=100;
                }
            }

        }
    }

    public void render(Graphics g) {
        ImageIcon zombies = new ImageIcon("ConeHeadZombie.gif");

//        Graphics2D g2d = (Graphics2D) g;
//        g.setColor(Color.black);
//        g2d.draw(getBounds());

        g.drawImage(zombies.getImage() , x, y,null);
        if(Health==0){
            handler.removeObject(this);
        }
        g.setColor(Color.gray);
        g.fillRect(x+15,y+105,50,5);

        g.setColor(Color.green);
        g.fillRect(x+15,y+105,Health/4,5);

        g.setColor(Color.white);
        g.drawRect(x+15,y+105,50,5);

        if(x==240){
            System.out.println("true");
            handler.looseGame(g);
            MouseInput.overClick=true;
        }
    }

    public Rectangle getBounds() {
        return new Rectangle(x,y+25,65,75);
    }

}
