public enum ID {
//////////////////////////////////an enum class that my objects in here to use them easier//////////////////////////////
    SunFlower(),
    PeaShooter(),
    Potato(),
    ReaPeater(),
    pea(),
    NormalZombie(),
    ConeHeadZombie();
}
