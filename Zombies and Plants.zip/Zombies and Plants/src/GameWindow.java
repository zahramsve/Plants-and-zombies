import javax.swing.*;
import java.awt.*;

public class GameWindow extends Canvas {
    static JFrame frame;
    private static final long serialVersionUID = -6792552159372506926L;
/////////////////////////////////////////Game frame and window//////////////////////////////////////////////////////////
    public GameWindow(int width , int height , String title , Game game){
        ImageIcon icon = new ImageIcon("iconImage.png");
        frame = new JFrame(title);

        frame.setPreferredSize(new Dimension(width,height));
        frame.setMaximumSize(new Dimension(width,height));
        frame.setMinimumSize(new Dimension(width,height));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);

        frame.add(game);
        frame.setIconImage(icon.getImage());
        frame.setVisible(true);
        game.start();
    }
}