import javax.swing.*;
import java.awt.*;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;

public class Main {
    public static int SunNSp,ZombieNSp,DoralNSp;
    public static final int Width =1100 , Height = Width*9 /16;//height=618
    static JFrame firstFrame = new JFrame("Plants VS. Zombies");
    static JPanel firstPanel = new JPanel();
    static JLabel firstLabel = new JLabel();

    static JFrame startFrame = new JFrame("Plants VS. Zombies");
    static JPanel startPanel = new JPanel();
    static JLabel startLabel = new JLabel();

    static JFrame onlineFrame = new JFrame("Plants VS. Zombies");
    static JPanel onlinePanel = new JPanel();
    static JLabel onlineLabel = new JLabel();

    static JFrame settingFrame = new JFrame("Plants VS. Zombies");
    static JPanel settingPanel = new JPanel();
    static JLabel settingLabel = new JLabel();

    public static void main(String[] args) {
        firstMenu();
    }

    public static void firstMenu(){
        ImageIcon icon = new ImageIcon("iconImage.png");
        ImageIcon MenuImage = new ImageIcon("menu image.jpg");

        JButton startB = new JButton("START");
        startB.setBounds(100,350,150,50);
        startB.setBackground(Color.BLACK);
        startB.setForeground(Color.WHITE);
        startB.setBorder(BorderFactory.createEtchedBorder());
        startB.setFocusable(false);
        firstPanel.add(startB);

        JButton settingB = new JButton("SETTING");
        settingB.setBounds(500,350,150,50);
        settingB.setBackground(Color.BLACK);
        settingB.setForeground(Color.WHITE);
        settingB.setBorder(BorderFactory.createEtchedBorder());
        settingB.setFocusable(false);
        firstPanel.add(settingB);

        JButton exitB = new JButton("EXIT");
        exitB.setBounds(850,350,150,50);
        exitB.setBackground(Color.BLACK);
        exitB.setForeground(Color.WHITE);
        exitB.setBorder(BorderFactory.createEtchedBorder());
        exitB.setFocusable(false);
        firstPanel.add(exitB);


        firstLabel.setBounds(0,0,Width,Height);
        firstLabel.setIcon(MenuImage);


        firstPanel.setPreferredSize(new Dimension(Width,Height));
        firstPanel.setMaximumSize(new Dimension(Width,Height));
        firstPanel.setMinimumSize(new Dimension(Width,Height));
        firstPanel.setLayout(null);

        firstPanel.add(firstLabel);

        firstFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        firstFrame.setContentPane(firstPanel);
        firstFrame.pack();

        firstFrame.setIconImage(icon.getImage());
        firstFrame.setLocationRelativeTo(null);
        firstFrame.setResizable(false);
        firstFrame.setVisible(true);

        startB.addActionListener(e -> {
            firstFrame.setVisible(false);
            startMenu();
        });

        settingB.addActionListener(e -> {
            settingMenu();
            firstFrame.setVisible(false);

        });

        exitB.addActionListener(e -> {
            firstFrame.dispose();
        });

    }

    public static void startMenu(){
        ImageIcon icon = new ImageIcon("iconImage.png");
        ImageIcon MenuImage = new ImageIcon("menu image.jpg");

        JButton offlineB = new JButton("OFFLINE");
        offlineB.setBounds(450,200,200,50);
        offlineB.setBackground(Color.BLACK);
        offlineB.setForeground(Color.WHITE);
        offlineB.setBorder(BorderFactory.createEtchedBorder());
        offlineB.setFocusable(false);
        startPanel.add(offlineB);

        JButton onlineB = new JButton("ONLINE");
        onlineB.setBounds(450,300,200,50);
        onlineB.setBackground(Color.BLACK);
        onlineB.setForeground(Color.WHITE);
        onlineB.setBorder(BorderFactory.createEtchedBorder());
        onlineB.setFocusable(false);
        startPanel.add(onlineB);

        JButton backB = new JButton("BACK");
        backB.setBounds(450,400,200,50);
        backB.setBackground(Color.BLACK);
        backB.setForeground(Color.WHITE);
        backB.setBorder(BorderFactory.createEtchedBorder());
        backB.setFocusable(false);
        startPanel.add(backB);

        JButton exitB = new JButton("EXIT");
        exitB.setBounds(450,500,200,50);
        exitB.setBackground(Color.BLACK);
        exitB.setForeground(Color.WHITE);
        exitB.setBorder(BorderFactory.createEtchedBorder());
        exitB.setFocusable(false);
        startPanel.add(exitB);


        startLabel.setBounds(0,0,Width,Height);
        startLabel.setIcon(MenuImage);


        startPanel.setPreferredSize(new Dimension(Width,Height));
        startPanel.setMaximumSize(new Dimension(Width,Height));
        startPanel.setMinimumSize(new Dimension(Width,Height));
        startPanel.setLayout(null);

        startPanel.add(startLabel);

        startFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        startFrame.setContentPane(startPanel);
        startFrame.pack();

        startFrame.setIconImage(icon.getImage());
        startFrame.setLocationRelativeTo(null);
        startFrame.setResizable(false);
        startFrame.setVisible(true);

        offlineB.addActionListener(e -> {
            new Game();
            startFrame.setVisible(false);
        });

        onlineB.addActionListener(e -> {
            onlineMenu();
            startFrame.setVisible(false);
        });

        backB.addActionListener(e -> {
            startFrame.setVisible(false);
            firstFrame.setVisible(true);
        });

        exitB.addActionListener(e -> {
            startFrame.dispose();
            firstFrame.dispose();
        });

    }

    public static void onlineMenu(){
        ImageIcon icon = new ImageIcon("iconImage.png");
        ImageIcon MenuImage = new ImageIcon("menu image.jpg");


        JButton serverB = new JButton("ONLINE SERVER");
        serverB.setBounds(450,300,200,50);
        serverB.setBackground(Color.BLACK);
        serverB.setForeground(Color.WHITE);
        serverB.setBorder(BorderFactory.createEtchedBorder());
        serverB.setFocusable(false);
        onlinePanel.add(serverB);

        JButton clientB = new JButton("ONLINE CLIENT");
        clientB.setBounds(450,400,200,50);
        clientB.setBackground(Color.BLACK);
        clientB.setForeground(Color.WHITE);
        clientB.setBorder(BorderFactory.createEtchedBorder());
        clientB.setFocusable(false);
        onlinePanel.add(clientB);


        onlineLabel.setBounds(0,0,Width,Height);
        onlineLabel.setIcon(MenuImage);


        onlinePanel.setPreferredSize(new Dimension(Width,Height));
        onlinePanel.setMaximumSize(new Dimension(Width,Height));
        onlinePanel.setMinimumSize(new Dimension(Width,Height));
        onlinePanel.setLayout(null);

        onlinePanel.add(onlineLabel);

        onlineFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        onlineFrame.setContentPane(onlinePanel);
        onlineFrame.pack();

        onlineFrame.setIconImage(icon.getImage());
        onlineFrame.setLocationRelativeTo(null);
        onlineFrame.setResizable(false);
        onlineFrame.setVisible(true);
    }

    public static void settingMenu(){
        ImageIcon icon = new ImageIcon("iconImage.png");
        ImageIcon MenuImage = new ImageIcon("setting menu.jpg");


        SpinnerModel sunSp = new SpinnerNumberModel(50,25,200,25);
        JSpinner sunSpinner = new JSpinner(sunSp);
        sunSpinner.setBounds(600,160,100,50);
        settingPanel.add(sunSpinner);


        SpinnerModel zombieSp = new SpinnerNumberModel(10,5,50,1);
        JSpinner zombieSpinner = new JSpinner(zombieSp);
        zombieSpinner.setBounds(600,280,100,50);
        settingPanel.add(zombieSpinner);

        SpinnerModel doralSp = new SpinnerNumberModel(50,0,200,25);
        JSpinner doralSpinner = new JSpinner(doralSp);
        doralSpinner.setBounds(600,400,100,50);
        settingPanel.add(doralSpinner);


        JButton backB = new JButton("BACK");
        backB.setBounds(300,500,150,50);
        backB.setBackground(Color.BLACK);
        backB.setForeground(Color.WHITE);
        backB.setBorder(BorderFactory.createEtchedBorder());
        backB.setFocusable(false);
        settingPanel.add(backB);

        JButton summitB = new JButton("SUMMIT");
        summitB.setBounds(600,500,150,50);
        summitB.setBackground(Color.BLACK);
        summitB.setForeground(Color.WHITE);
        summitB.setBorder(BorderFactory.createEtchedBorder());
        summitB.setFocusable(false);
        settingPanel.add(summitB);

        settingLabel.setBounds(0,0,Width,Height);
        settingLabel.setIcon(MenuImage);


        settingPanel.setPreferredSize(new Dimension(Width,Height));
        settingPanel.setMaximumSize(new Dimension(Width,Height));
        settingPanel.setMinimumSize(new Dimension(Width,Height));
        settingPanel.setLayout(null);

        settingPanel.add(settingLabel);

        settingFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        settingFrame.setContentPane(settingPanel);
        settingFrame.pack();

        settingFrame.setIconImage(icon.getImage());
        settingFrame.setLocationRelativeTo(null);
        settingFrame.setResizable(false);
        settingFrame.setVisible(true);

        backB.addActionListener(e -> {
            settingFrame.setVisible(false);
            firstFrame.setVisible(true);
        });
        summitB.addActionListener(e -> {
            SunNSp =(Integer)sunSp.getValue();
            ZombieNSp = (Integer)zombieSp.getValue();
            DoralNSp = (Integer)doralSp.getValue();
            settingFrame.setVisible(false);
            firstFrame.setVisible(true);
            System.out.println(SunNSp);
            System.out.println(ZombieNSp);
            System.out.println(DoralNSp);
        });

    }

}
