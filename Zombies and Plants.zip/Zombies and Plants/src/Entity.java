import java.awt.*;

public abstract class Entity {

    protected int x,y;
    protected ID id;
    protected Double velX, velY;
    /*
     velocity x vs y that are going to control the speed in the x direction
     , in the speed in our y
     */

//////////////////////////when we create child class from this class we must set this three parameter///////////////////
    public Entity(int x , int y ,ID id){
        this.x = x;
        this.y = y;
        this.id = id;
    }

    public abstract void tick();

    public abstract void render(Graphics g);
    public abstract Rectangle getBounds();

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public ID getId() {
        return id;
    }

    public void setId(ID id) {
        this.id = id;
    }

    public Double getVelX() {
        return velX;
    }

    public void setVelX(Double velX) {
        this.velX = velX;
    }

    public Double getVelY() {
        return velY;
    }

    public void setVelY(Double velY) {
        this.velY = velY;
    }
}
