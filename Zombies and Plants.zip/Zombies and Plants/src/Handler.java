import javax.swing.*;
import java.awt.*;
import java.util.Vector;

public class Handler {
////////////////////////////////////For handle objects that add to the window///////////////////////////////////////////
    Vector<Entity> object = new Vector<Entity>();

    public void tick(){
        for (int i=0 ; i<object.size();i++){
            Entity tempObject = object.get(i);
            tempObject.tick();
        }
    }

    public void render(Graphics g){
        for (int i=0 ; i<object.size();i++){
            Entity tempObject = object.get(i);
            tempObject.render(g);
        }
    }
    public void looseGame(Graphics g){
        Game.running = false;
        ImageIcon Loose = new ImageIcon("loose pic.jpg");
        g.drawImage(Loose.getImage() ,0,0,Game.Width,Game.Height-47,null);
//        g.setColor(Color.BLACK);
//        g.drawLine(700,200,700,600);
        for (int i=0 ; i<object.size();i++){
            removeObject(object.get(i));
        }
    }
    public void winGame(Graphics g){
        Game.running = false;
        ImageIcon win = new ImageIcon("win pic.jpg");
        //g.drawImage(win.getImage() ,0,0,Game.Width,Game.Height-47,null);
        System.out.println("win tar");
//        g.setColor(Color.BLACK);
//        g.drawLine(700,200,700,600);
        for (int i=0 ; i<object.size();i++){
            removeObject(object.get(i));
        }
    }


    public void addObject(Entity object){
        this.object.add(object);
    }

    public void removeObject(Entity object){
        this.object.remove(object);
    }
}
